# Batch Upsert Flow Action
This is intended to provide a flow action that can be used to Bulk Upsert records to salesforce. This can be used in conjunction with other steps like a csv file upload and parse tool to provide a tool for clients to upsert records within a salesforce flow screen or to automatically process new files uploaded with specific formats and settings on certain object pages.
